#!/bin/bash

# ====================================================================
# Comprehensive Project Check Script (.NET)
# 
# Purpose: 執行所有專案檢查腳本，提供完整的專案健康報告
# Usage: ./check-all.sh [--quick | --full | --critical]
# ====================================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Parse arguments strictly so a typo cannot silently select the full gate.
MODE="full"
if [ "$#" -gt 1 ]; then
    echo "Usage: $0 [--quick | --full | --critical]" >&2
    exit 2
elif [ "$#" -eq 1 ] && { [ "$1" == "--help" ] || [ "$1" == "-h" ]; }; then
    echo "Usage: $0 [--quick | --full | --critical]"
    echo ""
    echo "Modes:"
    echo "  --quick    : Only run fast, critical checks"
    echo "  --critical : Only run the most important checks"
    echo "  --full     : Run all available checks (default)"
    echo ""
    exit 0
elif [ "$#" -eq 1 ]; then
    case "$1" in
        --quick) MODE="quick" ;;
        --critical) MODE="critical" ;;
        --full) MODE="full" ;;
        *)
            echo "Unknown argument: $1" >&2
            echo "Usage: $0 [--quick | --full | --critical]" >&2
            exit 2
            ;;
    esac
fi

# Resolve the existing Python contract across Windows Git Bash and POSIX hosts.
# Keep literal `python ...` command declarations below for shell-manifest parity.
resolve_python() {
    local candidate directory possible name old_ifs
    if [ -n "${AI_CONTEXT_PYTHON:-}" ]; then
        if command -v "$AI_CONTEXT_PYTHON" >/dev/null 2>&1 &&
            "$AI_CONTEXT_PYTHON" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)' >/dev/null 2>&1; then
            command -v "$AI_CONTEXT_PYTHON"
            return 0
        fi
        return 1
    fi

    if [ -n "${VIRTUAL_ENV:-}" ]; then
        if [ -x "$VIRTUAL_ENV/Scripts/python.exe" ]; then
            candidate=$VIRTUAL_ENV/Scripts/python.exe
        else
            candidate=$VIRTUAL_ENV/bin/python
        fi
        if [ -x "$candidate" ] &&
            "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)' >/dev/null 2>&1; then
            printf '%s\n' "$candidate"
            return 0
        fi
    fi

    for candidate in python python3; do
        if command -v "$candidate" >/dev/null 2>&1 &&
            "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)' >/dev/null 2>&1; then
            command -v "$candidate"
            return 0
        fi
    done

    old_ifs=$IFS
    IFS=:
    for directory in $PATH; do
        [ -n "$directory" ] || directory=.
        for possible in "$directory"/python*; do
            [ -x "$possible" ] || continue
            name=${possible##*/}
            case "$name" in
                python3.[0-9]*|python3[0-9]*|python[0-9][0-9]*)
                    if "$possible" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)' >/dev/null 2>&1; then
                        IFS=$old_ifs
                        printf '%s\n' "$possible"
                        return 0
                    fi
                    ;;
            esac
        done
    done
    IFS=$old_ifs

    if command -v uv >/dev/null 2>&1; then
        candidate=$(uv python find --managed-python --no-python-downloads --offline --no-config --no-project ">=3.11" 2>/dev/null || true)
        if [ -n "$candidate" ] &&
            "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)' >/dev/null 2>&1; then
            printf '%s\n' "$candidate"
            return 0
        fi
    fi
    return 1
}

if ! PYTHON_EXECUTABLE="$(resolve_python)"; then
    echo -e "${YELLOW}⊘ BLOCKED-BY-ENVIRONMENT${NC}: Python 3.11 or newer is required. Install source dependencies from requirements.txt or set AI_CONTEXT_PYTHON to a usable interpreter." >&2
    exit 3
fi
export AI_CONTEXT_PYTHON="$PYTHON_EXECUTABLE"

python() {
    "$PYTHON_EXECUTABLE" "$@"
}

# Track results
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0
SKIPPED_CHECKS=0
WARNINGS=0
REQUIRED_SELECTED=0
REQUIRED_RUN=0
REQUIRED_FAILED=0
ADVISORY_SELECTED=0
DEFERRED_CHECKS=0
NOT_APPLICABLE=0
BLOCKED_CHECKS=0
REQUIRED_BLOCKED=0
CHECK_TIMINGS=()
BLOCKED_LIST=()
TOTAL_ELAPSED_START=$SECONDS

select_check() {
    local description=$1
    local is_critical=$2
    local is_quick=$3
    if [ "$MODE" == "critical" ] && [ "$is_critical" != "true" ]; then
        echo -e "${YELLOW}⊖${NC} Skipping by mode: $description (non-critical)"
        SKIPPED_CHECKS=$((SKIPPED_CHECKS + 1))
        return 1
    fi
    if [ "$MODE" == "quick" ] && [ "$is_quick" != "true" ]; then
        echo -e "${YELLOW}⊖${NC} Skipping by mode: $description (not quick)"
        SKIPPED_CHECKS=$((SKIPPED_CHECKS + 1))
        return 1
    fi
    return 0
}

record_selected() {
    local enforcement=$1
    if [ "$enforcement" != "required" ] && [ "$enforcement" != "advisory" ]; then
        echo "Internal error: unsupported enforcement class '$enforcement'" >&2
        exit 2
    fi
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    if [ "$enforcement" == "required" ]; then
        REQUIRED_SELECTED=$((REQUIRED_SELECTED + 1))
    else
        ADVISORY_SELECTED=$((ADVISORY_SELECTED + 1))
    fi
}

record_unavailable_or_failed() {
    local enforcement=$1
    local description=$2
    if [ "$enforcement" == "required" ]; then
        echo -e "${RED}✗ FAILED${NC}: $description"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
        REQUIRED_FAILED=$((REQUIRED_FAILED + 1))
    else
        echo -e "${YELLOW}⚠ ADVISORY${NC}: $description"
        WARNINGS=$((WARNINGS + 1))
    fi
}

record_timing() {
    local elapsed=$1
    local description=$2
    local outcome=$3
    CHECK_TIMINGS+=("${elapsed}|${outcome}|${description}")
}

# Return a reason only for unambiguous host/runtime failures. Keep this list
# deliberately narrow: repository defects must continue to fail normally.
classify_environment_block() {
    local output=$1
    case "$output" in
        *'"outcome":"blocked-by-environment"'*|*"Python prerequisite blocked"*)
            printf '%s\n' "python-prerequisite"
            return 0
            ;;
        *"python: command not found"*|*"python3: command not found"*)
            printf '%s\n' "missing-python"
            return 0
            ;;
        *"dotnet: command not found"*|*"No .NET SDKs were found"*)
            printf '%s\n' "missing-dotnet-sdk"
            return 0
            ;;
        *"Could not resolve host"*|*"Name or service not known"*|*"Network is unreachable"*|*"No connection could be made"*)
            printf '%s\n' "network-unavailable"
            return 0
            ;;
        *"Read-only file system"*)
            printf '%s\n' "read-only-filesystem"
            return 0
            ;;
    esac
    return 1
}

record_environment_block() {
    local enforcement=$1
    local description=$2
    local reason=$3
    echo -e "${YELLOW}⊘ BLOCKED-BY-ENVIRONMENT${NC}: $description ($reason)"
    BLOCKED_CHECKS=$((BLOCKED_CHECKS + 1))
    BLOCKED_LIST+=("${reason}|${description}")
    if [ "$enforcement" == "required" ]; then
        REQUIRED_BLOCKED=$((REQUIRED_BLOCKED + 1))
    fi
}

# Function to run a check script
run_check() {
    local script_name=$1
    local description=$2
    local enforcement=$3
    local is_critical=$4
    local is_quick=$5
    shift 5
    local args=("$@")
    local elapsed_start=$SECONDS
    local output rc reason outcome
    select_check "$description" "$is_critical" "$is_quick" || return
    record_selected "$enforcement"
    
    echo ""
    echo -e "${CYAN}▶ Running:${NC} $description"
    echo "  Script: $script_name"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    
    if [ -f "$SCRIPT_DIR/$script_name" ]; then
        if [ -x "$SCRIPT_DIR/$script_name" ]; then
            [ "$enforcement" == "required" ] && REQUIRED_RUN=$((REQUIRED_RUN + 1))
            if output=$("$SCRIPT_DIR/$script_name" "${args[@]}" 2>&1); then
                rc=0
            else
                rc=$?
            fi
            printf '%s\n' "$output"
            if [ "$rc" -eq 0 ]; then
                echo -e "${GREEN}✓ PASSED${NC}: $description"
                PASSED_CHECKS=$((PASSED_CHECKS + 1))
                outcome="passed"
            elif reason=$(classify_environment_block "$output"); then
                record_environment_block "$enforcement" "$description" "$reason"
                outcome="blocked"
            else
                record_unavailable_or_failed "$enforcement" "$description returned non-zero"
                outcome="failed"
            fi
        else
            record_unavailable_or_failed "$enforcement" "$script_name is not executable"
            outcome="unavailable"
        fi
    else
        record_unavailable_or_failed "$enforcement" "$script_name not found"
        outcome="unavailable"
    fi

    record_timing "$((SECONDS - elapsed_start))" "$description" "$outcome"
    
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

run_command_check() {
    local command_text=$1
    local description=$2
    local enforcement=$3
    local is_critical=$4
    local is_quick=$5
    local elapsed_start=$SECONDS
    local output rc reason outcome
    select_check "$description" "$is_critical" "$is_quick" || return
    record_selected "$enforcement"
    [ "$enforcement" == "required" ] && REQUIRED_RUN=$((REQUIRED_RUN + 1))

    echo ""
    echo -e "${CYAN}▶ Running:${NC} $description"
    echo "  Command: $command_text"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

    if output=$( (cd "$PROJECT_ROOT" && eval "$command_text") 2>&1); then
        rc=0
    else
        rc=$?
    fi
    printf '%s\n' "$output"
    if [ "$rc" -eq 0 ]; then
        echo -e "${GREEN}✓ PASSED${NC}: $description"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
        outcome="passed"
    elif reason=$(classify_environment_block "$output"); then
        record_environment_block "$enforcement" "$description" "$reason"
        outcome="blocked"
    else
        record_unavailable_or_failed "$enforcement" "$description returned non-zero"
        outcome="failed"
    fi

    record_timing "$((SECONDS - elapsed_start))" "$description" "$outcome"

    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

# Function to mark a check as pending dotnet-native replacement
run_deferred_check() {
    local script_name=$1
    local description=$2
    local is_critical=$3
    local is_quick=$4
    local reason=${5:-"dotnet-native replacement pending"}

    select_check "$description" "$is_critical" "$is_quick" || return
    echo -e "${YELLOW}⊖${NC} DEFERRED: $description ($reason)"
    DEFERRED_CHECKS=$((DEFERRED_CHECKS + 1))
}

run_spec_compliance_check() {
    local spec_file="${SPEC_FILE:-}"
    local task_name="${TASK_NAME:-}"

    if [ -z "$spec_file" ] && [ -z "$task_name" ]; then
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: Spec Implementation Compliance (SPEC_FILE/TASK_NAME not set)"
        NOT_APPLICABLE=$((NOT_APPLICABLE + 1))
        return
    fi
    if [ -z "$spec_file" ] || [ -z "$task_name" ]; then
        echo -e "${RED}✗ FAILED${NC}: Spec Implementation Compliance requires both SPEC_FILE and TASK_NAME"
        TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
        REQUIRED_SELECTED=$((REQUIRED_SELECTED + 1))
        REQUIRED_FAILED=$((REQUIRED_FAILED + 1))
        return
    fi

    run_check "check-spec-compliance.sh" \
        "Spec Implementation Compliance (.NET)" \
        "required" "false" "true" "$spec_file" "$task_name"
}

source_release_context_available() {
    [ -d "$PROJECT_ROOT/.dev/releases" ] &&
        [ -d "$PROJECT_ROOT/.ai/distribution" ] &&
        [ -f "$PROJECT_ROOT/.ai/scripts/ai_context_package.py" ]
}

run_source_repository_dotnet_framework_tests() {
    if ! source_release_context_available; then
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: Dotnet Backend Analyzer Template Tests (source framework tests not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: Dotnet Backend Configuration Validation Tests (source framework tests not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: Dotnet Backend BuildingBlocks Behavior Tests (source framework tests not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: Bundled Mechanical Validation Provider Activation Tests (source framework tests not packaged)"
        NOT_APPLICABLE=$((NOT_APPLICABLE + 4))
        return
    fi

    run_command_check "dotnet test tools/DotnetBackendAnalyzers.Tests/DotnetBackendAnalyzers.Tests.csproj" \
        "Dotnet Backend Analyzer Template Tests" \
        "required" "true" "true"

    run_command_check "dotnet test tools/DotnetBackendValidation.Tests/DotnetBackendValidation.Tests.csproj" \
        "Dotnet Backend Configuration Validation Tests" \
        "required" "true" "true"

    run_command_check "dotnet test tools/DotnetBackendBuildingBlocks.Tests/DotnetBackendBuildingBlocks.Tests.csproj" \
        "Dotnet Backend BuildingBlocks Behavior Tests" \
        "required" "true" "true"

    run_command_check "python .ai/assets/tech-stacks/dotnet-backend/tooling/bundled-mechanical-validation/tests/test_provider_activation_evaluator.py -v" \
        "Bundled Mechanical Validation Provider Activation Tests" \
        "required" "true" "true"
}

run_source_repository_release_checks() {
    if ! source_release_context_available; then
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: AI Context Version Governance Fail-Closed Tests (source release context not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: AI Context Packaging GWT Tests (source package builder not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: AI Context Release State Fail-Closed Tests (source release context not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: AI Context Release Preparation Fail-Closed Tests (source release context not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: AI Context Release Renderer Fail-Closed Tests (source release context not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: AI Behavior Deterministic Evaluation (source release context not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: AI Context Load Measurement Contract (source release context not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: Repository Configuration Ownership Contract (source release context not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: Repository Configuration Ownership Fail-Closed Tests (source release context not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: Skill Transition Compatibility Contract (source release context not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: Skill Transition Compatibility Fail-Closed Tests (source release context not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: Effective Rule Packet Resolution and Consumer Parity Tests (source release context not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: Effective Rule Action Skill Consumption Contract (source release context not packaged)"
        NOT_APPLICABLE=$((NOT_APPLICABLE + 13))
        return
    fi

    run_command_check "python .ai/scripts/tests/test_ai_context_version_governance.py -v" \
        "AI Context Version Governance Fail-Closed Tests" \
        "required" "true" "true"

    run_command_check "python .ai/scripts/tests/test_ai_context_packaging.py -v" \
        "AI Context Packaging GWT Tests" \
        "required" "true" "true"

    run_command_check "python .ai/scripts/tests/test_ai_context_release_state.py -v" \
        "AI Context Release State Fail-Closed Tests" \
        "required" "true" "true"

    run_command_check "python .ai/scripts/tests/test_prepare_ai_context_release.py -v" \
        "AI Context Release Preparation Fail-Closed Tests" \
        "required" "true" "true"

    run_command_check "python .ai/scripts/tests/test_release_notes_renderer.py -v" \
        "AI Context Release Renderer Fail-Closed Tests" \
        "required" "true" "true"

    run_command_check "python .ai/scripts/tests/test_ai_behavior_evaluation.py -v" \
        "AI Behavior Deterministic Evaluation" \
        "required" "true" "true"

    run_command_check "python .ai/scripts/tests/test_ai_context_load_measurement.py -v" \
        "AI Context Load Measurement Contract" \
        "required" "true" "true"

    run_command_check "python .ai/scripts/validate-repository-config-contract.py" \
        "Repository Configuration Ownership Contract" \
        "required" "true" "true"

    run_command_check "python .ai/scripts/tests/test_repository_config_contract.py -v" \
        "Repository Configuration Ownership Fail-Closed Tests" \
        "required" "true" "true"

    run_command_check "python .ai/scripts/validate-skill-transition.py" \
        "Skill Transition Compatibility Contract" \
        "required" "true" "true"

    run_command_check "python .ai/scripts/tests/test_skill_transition_contract.py -v" \
        "Skill Transition Compatibility Fail-Closed Tests" \
        "required" "true" "true"

    run_command_check "python .ai/scripts/tests/test_ai_context_effective_rules.py -v" \
        "Effective Rule Packet Resolution and Consumer Parity Tests" \
        "required" "true" "true"

    run_command_check "python .ai/scripts/tests/test_effective_rule_action_skill_contract.py -v" \
        "Effective Rule Action Skill Consumption Contract" \
        "required" "true" "true"
}

run_ai_context_version_check() {
    if source_release_context_available; then
        run_command_check "python .ai/scripts/validate-ai-context-versions.py" \
            "AI Context Release And Version Contracts" \
            "required" "true" "true"
    elif [ -f "$PROJECT_ROOT/.dev/ai-context/provenance.yaml" ] || \
         [ -f "$PROJECT_ROOT/.dev/AI-CONTEXT-APPLY-PENDING.yaml" ]; then
        run_command_check "python .ai/scripts/validate-ai-context-target.py" \
            "AI Context Target Apply, Provenance And Customization Contracts" \
            "required" "true" "true"
    else
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: AI Context Target Provenance And Customization Contracts (target provenance not initialized)"
        NOT_APPLICABLE=$((NOT_APPLICABLE + 1))
    fi
}

source_governance_context_available() {
    source_release_context_available &&
        [ -f "$PROJECT_ROOT/.github/workflows/governance.yml" ] &&
        [ -f "$PROJECT_ROOT/.ai/distribution/governance-checks.yaml" ] &&
        [ -f "$PROJECT_ROOT/.ai/scripts/validate-source-governance.py" ]
}

run_source_repository_governance_checks() {
    if ! source_governance_context_available; then
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: Source Governance Manifest Registry (source governance registry not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: Governance Pull-Request Workflow Contract (source CI workflow not packaged)"
        echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: GitHub Workflow Lifecycle Contract (source CI workflows not packaged)"
        NOT_APPLICABLE=$((NOT_APPLICABLE + 3))
        return
    fi

    run_command_check "python .ai/scripts/validate-source-governance.py" \
        "Source Governance Manifest Registry" \
        "required" "true" "true"

    run_command_check "python .ai/scripts/tests/test_governance_workflow_contract.py -v" \
        "Governance Pull-Request Workflow Contract" \
        "required" "true" "true"

    run_command_check "python .ai/scripts/tests/test_github_workflow_contract.py -v" \
        "GitHub Workflow Lifecycle Contract" \
        "required" "true" "true"
}

# Header
echo ""
echo -e "${MAGENTA}╔════════════════════════════════════════╗${NC}"
echo -e "${MAGENTA}║    Comprehensive Project Check         ║${NC}"
echo -e "${MAGENTA}║    Mode: ${YELLOW}$MODE${MAGENTA}                          ║${NC}"
echo -e "${MAGENTA}╚════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BLUE}Starting checks at $(date '+%Y-%m-%d %H:%M:%S')${NC}"

# ====================================================================
# Critical Checks (always run in quick and critical modes)
# ====================================================================

echo ""
echo -e "${MAGENTA}════ Critical Checks ════${NC}"

run_command_check "python .ai/scripts/validate-assessment-artifacts.py" \
    "Assessment Artifact Metadata" \
    "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_assessment_artifacts.py -v" \
    "Assessment Artifact Fail-Closed Tests" \
    "required" "true" "true"

  run_command_check "python .ai/scripts/validate-workflow-artifacts.py" \
      "Workflow Artifact Metadata" \
      "required" "true" "true"

run_command_check "python .ai/assets/skills/software-development-orchestrator/scripts/tests/test_workflow_implementation_contract.py -v" \
      "Workflow Implementation Contract Fail-Closed Tests" \
      "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_workflow_lifecycle_contract.py -v" \
    "Workflow Lifecycle Contract Fail-Closed Tests" \
    "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_git_commit_policy.py -v" \
    "Git Commit Policy Fail-Closed Tests" \
    "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_workflow_handoff.py -v" \
    "Workflow Handoff Fail-Closed Tests" \
    "required" "true" "true"

run_command_check "python .ai/scripts/validate-workflow-handoff.py --all" \
    "Registered Workflow Handoff Checkpoints" \
    "required" "true" "true"

run_command_check "python .ai/assets/skills/software-development-orchestrator/scripts/tests/test_software_development_orchestrator_capability_contract.py -v" \
    "Development Workflow Capability Contract" \
    "required" "true" "true"

run_command_check "python .ai/assets/skills/software-development-orchestrator/scripts/tests/test_software_development_orchestrator_acceptance.py -v" \
    "Development Workflow Deterministic Acceptance" \
    "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_skill_script_colocation.py -v" \
    "Canonical Skill Script Colocation Contract" \
    "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_semantic_customization_lifecycle.py -v" \
    "Semantic Customization Lifecycle" \
    "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_semantic_customization_skill_contract.py -v" \
    "Semantic Customization Skill Contract" \
    "required" "true" "true"

if [ -n "${COMMIT_RANGE:-}" ]; then
    COMMIT_VALIDATION_COMMAND="python .ai/scripts/validate-git-commits.py --range '$COMMIT_RANGE'"
    if [ -n "${WORKFLOW_ID:-}" ]; then
        COMMIT_VALIDATION_COMMAND="$COMMIT_VALIDATION_COMMAND --workflow-id '$WORKFLOW_ID'"
    fi
    run_command_check "$COMMIT_VALIDATION_COMMAND" \
        "Selected Git Commit Messages" \
        "required" "true" "true"
else
    echo -e "${CYAN}ℹ${NC} NOT APPLICABLE: Selected Git Commit Messages (COMMIT_RANGE not set)"
    NOT_APPLICABLE=$((NOT_APPLICABLE + 1))
fi

run_command_check "python .ai/scripts/validate-ai-context.py" \
    "AI Context Navigation and Runtime Contracts" \
    "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_ai_context_wrapper_metadata.py -v" \
    "AI Context Wrapper Semantic Contract Fail-Closed Tests" \
    "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_ai_context_language_policy.py -v" \
    "AI Context Language And Bilingual Parity Fail-Closed Tests" \
    "required" "true" "true"

run_ai_context_version_check

run_source_repository_release_checks

run_command_check "python .ai/scripts/tests/test_ai_context_package_apply.py -v" \
    "AI Context Safe Apply GWT Tests" \
    "required" "true" "true"

run_command_check "python .ai/scripts/validate-dependency-versions.py" \
    "Offline Dependency And Version Consistency" \
    "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_dependency_version_consistency.py -v" \
    "Dependency And Version Consistency Fail-Closed Tests" \
    "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_python_source_entrypoints.py -v" \
    "Source-Only Python Entrypoint Prerequisite Contract" \
    "required" "true" "true"

run_command_check "python .ai/scripts/validate-shell-assets.py" \
    "Shell Asset Classification And Git Modes" \
    "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_file_disposition_manifest.py -v" \
    "File Disposition Manifest Fail-Closed Tests" \
    "required" "true" "true"

run_source_repository_governance_checks

run_command_check "python .ai/scripts/tests/test_fail_closed_validation.py -v" \
    "Aggregate Runner And Shell Registry Fail-Closed Tests" \
    "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_coding_standards_integrity_contract.py -v" \
    "Coding Standards Integrity Claim Contract" \
    "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_profile_projection_contract.py -v" \
    "Profile Projection Contract" \
    "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_document_projection_contract.py -v" \
    "Documentation Projection Contract" \
    "required" "true" "true"

run_command_check "python .ai/scripts/tests/test_ai_context_source_include_evidence.py -v" \
    "Source-Include Evidence Contract" \
    "required" "true" "true"

# Coding standards are fundamental for AI context and standards docs
run_check "check-coding-standards.sh" \
    "Coding Standards Structural Integrity" \
    "required" "true" "true"

run_source_repository_dotnet_framework_tests

# Repository source validation is covered by DBA1001 in analyzer tests.
# Mapper source validation is covered by DBA1007-DBA1008 in analyzer tests.

# ====================================================================
# Important Checks (run in full and quick modes)
# ====================================================================

if [ "$MODE" != "critical" ]; then
    echo ""
    echo -e "${MAGENTA}════ Important Checks ════${NC}"
    
    # Aggregate and UseCase source validation is covered by DBA1002-DBA1003 and DBA1009-DBA1012.
    
    # Controller compliance is covered by DBA1004-DBA1006 in analyzer tests.

    # Projection source and EF model registration are covered by DBA1013 and configuration validation tests.
    
    # Spec compliance is important
    run_spec_compliance_check
    
fi

# ====================================================================
# Additional Checks (only in full mode)
# ====================================================================

if [ "$MODE" == "full" ]; then
    echo ""
    echo -e "${MAGENTA}════ Additional Checks ════${NC}"

    # Test DI compliance helper remains transitional
    run_deferred_check "check-test-di-compliance.sh" \
        "Test DI Compliance" \
        "true" "false" "replace with analyzer or test architecture rules"
    
    # Template sync check (dotnet-native replacement not yet available)
    run_deferred_check "check-template-sync.sh" \
        "Template Synchronization" \
        "false" "false" "dotnet-native replacement not yet available"
    
    # ADR index update (dotnet-native replacement not yet available)
    run_deferred_check "update-adr-index.sh" \
        "ADR Index Update" \
        "false" "false" "dotnet-native replacement not yet available"
    
    # Add ADR script (if needed)
    if [ -f "$SCRIPT_DIR/add-adr.sh" ]; then
        echo -e "${CYAN}ℹ${NC} add-adr.sh is available for creating new ADRs"
    fi
fi

# ====================================================================
# Results Summary
# ====================================================================

echo ""
echo -e "${MAGENTA}╔════════════════════════════════════════╗${NC}"
echo -e "${MAGENTA}║           Check Results Summary        ║${NC}"
echo -e "${MAGENTA}╚════════════════════════════════════════╝${NC}"
echo ""

# Calculate statistics
if [ $TOTAL_CHECKS -gt 0 ]; then
    PASS_RATE=$((PASSED_CHECKS * 100 / TOTAL_CHECKS))
else
    PASS_RATE=0
fi

# Display results with colors
echo -e "Total Checks Run: ${CYAN}$TOTAL_CHECKS${NC}"
echo -e "Passed: ${GREEN}$PASSED_CHECKS${NC}"
echo -e "Failed: ${RED}$FAILED_CHECKS${NC}"
echo -e "Blocked By Environment: ${YELLOW}$BLOCKED_CHECKS${NC}"
echo -e "Skipped By Mode: ${YELLOW}$SKIPPED_CHECKS${NC}"
echo -e "Advisory Warnings: ${YELLOW}$WARNINGS${NC}"
echo -e "Deferred: ${YELLOW}$DEFERRED_CHECKS${NC}"
echo -e "Not Applicable: ${CYAN}$NOT_APPLICABLE${NC}"
echo -e "Required Selected: ${CYAN}$REQUIRED_SELECTED${NC}"
echo -e "Required Executed: ${CYAN}$REQUIRED_RUN${NC}"
echo -e "Required Failed: ${RED}$REQUIRED_FAILED${NC}"
echo -e "Required Blocked: ${YELLOW}$REQUIRED_BLOCKED${NC}"
echo -e "Advisory Selected: ${CYAN}$ADVISORY_SELECTED${NC}"
echo -e "Pass Rate: ${CYAN}${PASS_RATE}%${NC}"

TOTAL_ELAPSED=$((SECONDS - TOTAL_ELAPSED_START))
echo ""
echo -e "${MAGENTA}──── Elapsed By Check (slowest first) ────${NC}"
if [ ${#CHECK_TIMINGS[@]} -gt 0 ]; then
    printf '%s\n' "${CHECK_TIMINGS[@]}" \
        | sort -t'|' -k1,1nr \
        | head -15 \
        | while IFS='|' read -r seconds outcome description; do
            printf "  %5ss  %-10s %s\n" "$seconds" "$outcome" "$description"
        done
fi
echo -e "  ${CYAN}Total wall time: ${TOTAL_ELAPSED}s across $TOTAL_CHECKS selected checks${NC}"
echo "AI_CONTEXT_CHECK_TIMING total_seconds=${TOTAL_ELAPSED} checks=${TOTAL_CHECKS} failed=${FAILED_CHECKS} blocked=${BLOCKED_CHECKS}"

if [ ${#BLOCKED_LIST[@]} -gt 0 ]; then
    echo ""
    echo -e "${YELLOW}──── Blocked By Environment (do NOT remediate code) ────${NC}"
    printf '%s\n' "${BLOCKED_LIST[@]}" | while IFS='|' read -r reason description; do
        printf "  %-24s %s\n" "$reason" "$description"
    done
    echo -e "  ${CYAN}These are host/runtime conditions. Prepare the environment, then re-run.${NC}"
fi

echo ""
echo -e "${BLUE}Completed at $(date '+%Y-%m-%d %H:%M:%S')${NC}"
echo ""

# Overall status
if [ $FAILED_CHECKS -eq 0 ] && [ $BLOCKED_CHECKS -eq 0 ] && [ $WARNINGS -eq 0 ]; then
    echo -e "${GREEN}╔════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║    ✓ All Checks Passed Successfully!   ║${NC}"
    echo -e "${GREEN}╚════════════════════════════════════════╝${NC}"
    exit 0
elif [ $FAILED_CHECKS -eq 0 ] && [ $BLOCKED_CHECKS -eq 0 ]; then
    echo -e "${YELLOW}╔════════════════════════════════════════╗${NC}"
    echo -e "${YELLOW}║  ⚠ Passed with $WARNINGS Advisory Warning(s) ║${NC}"
    echo -e "${YELLOW}╚════════════════════════════════════════╝${NC}"
    exit 0
elif [ $FAILED_CHECKS -eq 0 ]; then
    echo -e "${YELLOW}╔════════════════════════════════════════╗${NC}"
    echo -e "${YELLOW}║  ⊘ $BLOCKED_CHECKS check(s) blocked by environment  ║${NC}"
    echo -e "${YELLOW}╚════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${YELLOW}Next Steps:${NC}"
    echo "1. Do NOT modify repository code for these."
    echo "2. Prepare the host prerequisite listed above."
    echo "3. Re-run. Exit code 3 means unverified, never passed."
    exit 3
else
    echo -e "${RED}╔════════════════════════════════════════╗${NC}"
    echo -e "${RED}║    ✗ $FAILED_CHECKS Check(s) Failed!              ║${NC}"
    echo -e "${RED}╚════════════════════════════════════════╝${NC}"
    
    # Provide helpful next steps
    echo ""
    echo -e "${YELLOW}Next Steps:${NC}"
    echo "1. Review the failed checks above"
    echo "2. Run individual scripts for detailed errors"
    echo "3. Fix the issues and run this check again"
    echo ""
    
    exit 1
fi
