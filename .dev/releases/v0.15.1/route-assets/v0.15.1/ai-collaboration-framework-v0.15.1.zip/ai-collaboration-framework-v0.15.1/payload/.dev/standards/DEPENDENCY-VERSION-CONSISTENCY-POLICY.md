# Dependency Version Consistency Policy

## Purpose

This policy defines the deterministic offline dependency and runtime-version
gate for this AI context framework. The gate proves that repository-owned
declarations agree with each other. It does not claim that a selected version
is current, vulnerability-free, or suitable for a target product.

## Required Offline Contract

`python .ai/scripts/validate-dependency-versions.py` is a required repository
gate and must run without network access.

In the source framework repository it enforces:

- every direct Python requirement uses one exact `name==version` pin;
- root `requirements.txt` and
  `.ai/distribution/templates/requirements.txt` are byte-identical mirrors;
- GitHub workflows install Python dependencies through the root
  `requirements.txt`, rather than repeating package versions inline;
- all `actions/setup-python` steps declare the same exact Python version and
  satisfy the repository minimum of Python 3.11;
- the framework-owned tree contains no managed .NET project and therefore
  selects no framework `global.json`.

If a target explicitly creates target-owned `tools/**/*.csproj`, the validator
conditionally requires exact direct `PackageReference` versions, one version
per repeated package ID, and an exact target `global.json` whose SDK can build
the highest concrete `netN.0` target. `netstandard` targets do not require
SDK-major equality. A newer SDK may build a lower `netN.0` target; the gate
fails only when a selected SDK is too old for a selected managed tool.

## Installed-Repository Applicability

Source distribution controls and release workflows are not installed target
truth. Their checks apply only when the source requirements template is
present. An initialized target still executes the validator, but .NET checks
become applicable only after that target creates a managed `tools/**/*.csproj`;
only then must the target also select `global.json`.

The validator deliberately does not inspect target product package selections
outside `tools/`. Product dependency policy, central package management, and
technology selection remain target-owned.

## Online Advisory Boundary

Package currency and vulnerability information depends on mutable registries
and advisory databases. Such checks may run separately as visible advisory
evidence, but their absence or network failure must not be represented as an
offline consistency failure or success. A release claim must name any online
tool, database, timestamp, and executed environment explicitly.

## Runner And Portability Contract

`.ai/scripts/check-all.sh` retains its existing literal multiline declaration
format. `shell-assets.yaml` owns the set of required child scripts and commands,
and `validate-shell-assets.py` fails closed when the runner and manifest differ.
Formatting-contract fixtures must change with any future runner syntax change.

The current framework portability baseline requires the same required profile
to pass without `dotnet` on Windows Git Bash and hosted Ubuntu. macOS remains
unverified until separately executed; passing Unix-like hosts must not be
generalized into a macOS claim.

## Change Procedure

A source-repository dependency or runtime-version update must change every
governed mirror, workflow route, or managed project declaration in one coherent
change and pass the dependency-consistency, fail-closed, shell-asset, and quick
aggregate checks selected by the source validation registry. Those source test
commands are not portable package entrypoints; extracted candidates use their
checksum-governed incoming validator instead.

Online freshness or vulnerability results may inform the selected versions, but
they do not replace these deterministic checks.
