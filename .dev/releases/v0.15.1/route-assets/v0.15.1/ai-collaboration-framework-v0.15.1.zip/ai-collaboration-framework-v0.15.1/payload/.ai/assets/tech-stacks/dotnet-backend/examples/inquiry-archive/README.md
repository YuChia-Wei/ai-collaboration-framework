# Inquiry and Archive Patterns (.NET)

In addition to Repository and Projection, a CQRS architecture may use:
- **Inquiry**: targeted, read-only queries for complex conditions
- **Archive**: soft-delete and historical retention patterns

## Inquiry

Use Inquiry when:
- Cross-aggregate queries are required
- Reactors need read access to other aggregates
- Query logic is too specific for a projection

Do not use Inquiry for:
- Simple `FindById` (Repository)
- Standard list views (Projection)
- Data reachable via aggregate navigation

### Example (Interface)

```csharp
public interface IFindCardsByTagIdInquiry : IInquiry<TagId, IReadOnlyList<string>> { }
```

### Example (EF Core)

```csharp
public sealed class EfFindCardsByTagIdInquiry : IFindCardsByTagIdInquiry
{
    public IReadOnlyList<string> Query(TagId tagId) =>
        _db.Cards.Where(card => card.Tags.Any(tag => tag.TagId == tagId.Value))
                 .Select(card => card.CardId)
                 .ToList();
}
```

### Example (Event Store)

```csharp
public sealed class EsFindCardsByTagIdInquiry : IFindCardsByTagIdInquiry
{
    public IReadOnlyList<string> Query(TagId tagId) { /* scan events */ }
}
```

## Archive

Use Archive when:
- Soft-delete and audit retention are required
- Historical records must be preserved

Do not use Archive when:
- Data can be removed permanently
- Event sourcing already provides full history

### Example (Interface)

```csharp
public interface IUserArchive : IArchive<UserData, string> { }
```

### Example (EF Core)

```csharp
public sealed class EfUserArchive : IUserArchive
{
    public void Save(UserData entity) { /* persist */ }
}
```

The normal Archive port exposes lookup and save operations. Archive state and
audit metadata belong to the read-side data model and are persisted with
`Save`; do not add an ambiguous `Delete` operation or call EF Core `Remove`.
If a use case benefits from an explicit transition, name it `Archive` or
`MarkArchived` and retain the record.

Physical read-model cleanup is exceptional. Model it as a separate restricted
capability-specific port such as `IUserReadModelPurgePort.PurgeAsync`. Grant that
capability only after authorization, retention, legal-hold, audit-evidence, and
dependent-cleanup gates pass. It is not an aggregate purge port and must not be
injected into normal Reactor or CRUD flows.

## Inquiry vs Projection vs Archive

| Feature | Repository | Projection | Inquiry | Archive |
|---------|------------|------------|---------|---------|
| Purpose | Aggregate persistence | Read view | Complex query | Soft delete and retention |
| Writes | Yes | No | No | Yes |
| Output | Aggregate | DTO | IDs/DTO | Archived DTO |

## Related Resources
- `../projection/README.md`
- `../usecase/README.md`
