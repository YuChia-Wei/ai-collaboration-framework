---
name: ai-context-auditor
description: Analyze repository AI context structure, governance, routing, wrappers, semantic customization baselines, post-upgrade results, and validation surfaces. Return transient read-only findings unless persistence is requested; remain read-only and exclude product source/test code by default.
---

# AI Context Auditor

This is a thin current-runtime wrapper.

## Canonical Source

- Registry: `.ai/assets/skills/README.MD`
- Spec: `.ai/assets/skills/ai-context-auditor/skill.yaml`
- Human Guide: `.dev/guides/ai-collaboration-guides/AI-CONTEXT-AUDITOR-SKILL-GUIDE.md`
- References:
  - `.ai/assets/skills/ai-context-auditor/references/scope-and-routing.md`
  - `.ai/assets/skills/ai-context-auditor/references/audit-playbook.md`
  - `.ai/assets/skills/ai-context-auditor/references/output-contract.md`
  - `.ai/assets/skills/ai-context-governance/references/semantic-customization-lifecycle.md`
- Report Template: `.ai/assets/skills/ai-context-auditor/templates/ai-context-audit-report-template.md`
- Assessment Policy: `.dev/standards/ASSESSMENT-ARTIFACT-POLICY.md`
- Assessment Locator: `.dev/assessments/templates/assessment-locator-template.yaml`

## Wrapper Rules

Use this wrapper only as the current runtime entry.
Keep runtime-specific metadata in this wrapper directory only when the runtime requires it.
If wrapper text and canonical spec differ, follow `.ai/assets/skills/ai-context-auditor/skill.yaml`.
Remain read-only with respect to audited context. Hand remediation and lifecycle closure to `ai-context-governance`.
