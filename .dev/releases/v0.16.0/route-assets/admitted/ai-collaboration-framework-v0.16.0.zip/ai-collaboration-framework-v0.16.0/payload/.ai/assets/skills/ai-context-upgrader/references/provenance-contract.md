# Target Provenance Contract

The v0.6.0 installed target manifest path is
`.dev/ai-context/provenance.yaml`. Create it with the adjacent target-owned
`.dev/ai-context/customizations.yaml` ledger during initialization or governed
upgrade reconciliation. When explicit effective-state evidence is available,
create the adjacent `.dev/ai-context/effective-rules.yaml` state and packets
under `.dev/ai-context/effective-rule-packets/` through fail-closed staged
publication: packets first, state last, with rollback on in-process failure. A
process crash is not cross-file atomic, but no stale or mixed candidate may
pass the digest/freshness gates. If that evidence is not available, retain
structural initialization with
derived action readiness `action_ready: false`, `status: unresolved`, and
reason `effective-rule-state-missing`; create no empty state or packet, and
keep routine action work fail-closed until owner reconciliation. The readiness
result is derived output, not a provenance authority field.

Current effective-state publication uses `route-base32-60-v1` packet names:
`r-` plus the first 12 lowercase RFC 4648 Base32 characters derived from the
full route SHA-256, followed by `.yaml`. The full `ROUTE-<SHA256>` remains the
semantic identity and `effective-rules.yaml` remains the sole index. Complete
legacy full-route-id layouts remain readable. Ordinary package apply preserves
them; only explicitly authorized effective-state regeneration or finalization
may migrate them, with staged rollback and fail-closed recovery. Mixed layouts,
collisions, path mismatches, and orphan packet files are invalid.

`.dev/AI-CONTEXT-SOURCE.yaml` remains a schema-1 read-compatibility input for
older targets. Migrate it to the grouped path before writing schema 2. Never
retain both files as active authorities.

## Required Invariants

- `schema_version` is supported by the active upgrader.
- `source.repository` is a stable repository identity, not a local temporary path.
- `source.release_id` equals `REL-` plus `source.version`.
- `source.version` and `source.tag` are equal SemVer tags.
- `source.commit` is a full lowercase 40-character Git SHA and resolves to the tag when the source Git repository is available.
- `installation.imported_at` and non-null upgrade timestamps use ISO 8601 with an offset.
- Selected mandatory components, profiles, and providers are explicit.
- `customizations.ledger` is `.dev/ai-context/customizations.yaml`.
- `effective_rules.state` is `.dev/ai-context/effective-rules.yaml`,
  `effective_rules.packets_root` is `.dev/ai-context/effective-rule-packets/`,
  and both use the supported effective-rule schema version.
- The target-effective state pins the current provenance and customization
  digests, framework version and commit, selected profile, and fixed shared and
  selected-profile catalog paths and verified `catalog_digest.value` values.
  Its deterministic digest and each route packet digest must verify before an
  action uses them.
- Customization and unresolved-item IDs are unique and stable within the target repository.
- `last_migration.to_version` equals `source.version` after a completed upgrade.
- When present, `policy_adoptions.commit_subject_grammar` contains exactly the
  stable policy ID `git-commit-subject/v2`, a full lowercase
  `legacy_history_tip`, ISO-offset `adopted_at`, the raw SHA-256 of the
  installed incoming commit policy, and repository-relative `decision_evidence`.
  The installed policy bytes and Git history must still validate the record;
  adoption time is audit evidence only, not a historical grammar selector.

## Mutation Rules

- With credible source and selection evidence, `ai-context-init` uses
  fail-closed staged publication with in-process rollback for initial
  provenance and an empty customization ledger. With verified catalogs plus
  explicit target adoption/applicability and routing evidence, it additionally
  stages the required packets first and publishes the completed effective-rule
  state last. A process crash is not cross-file atomic; any stale or mixed
  candidate remains invalid. Without that latter evidence, it returns
  derived action readiness as `action_ready: false`, `status: unresolved`, and
  reason `effective-rule-state-missing`, creates no empty effective-rule state
  or packet, and awaits owner reconciliation. `repo-structure-sync` was retired
  in v0.16.0; preserve its historical provenance values and use `ai-context-init`
  for new initialization. Incomplete credible-source evidence produces an unresolved
  no-write result.
- `ai-context-upgrader` reads it during planning and uses fail-closed staged
  finalization with rollback on in-process failure only after owner
  reconciliation, independent post-upgrade audit, and target validation. It
  does not claim cross-file crash atomicity.
- Do not delete customizations merely because incoming framework paths changed;
  reconcile capability, rule, or contract equivalence and disposition.
- Do not change the source version to describe a partially applied or failed upgrade. Record such work under `reconciliation.unresolved` while retaining the last validated source.
- A package apply journal in `planned`, `applying`, `interrupted`,
  `awaiting-target-validation`, `rolling-back`, or `rolled-back` state never
  authorizes provenance advancement. Only a schema-2 pending receipt bound to a
  `validated` transaction, the same resolved target
  root and planned `HEAD`, exact sealed operation schema, selected-input proof,
  raw managed-path results, and intended Git modes may proceed to target
  validation. Target reads must not cross symlink or reparse boundaries. Resume
  and rollback preserve the last validated provenance bytes
  and cannot add selection or reconciliation authority.
- Newly written and recovered package-apply transactions use journal v5 only.
  Each completed apply operation or rollback path is appended as one canonical,
  fsynced `progress.jsonl` record before the next mutation begins; `journal.yaml`
  snapshots bind the compacted record count and tail digest. A trailing partial
  record is unacknowledged and may be discarded before the next append. New
  tooling never resumes, rolls back, migrates, or converts v4. An unfinished v4
  journal blocks new target mutation with the stable
  `unsupported-transaction-journal-version` classification and prior-tooling or
  owner-directed recovery guidance; terminal v4 evidence remains archival and
  does not block an unrelated v5 transaction.
- A source-version advancement additionally requires a fresh sealed
  `upgrade-remediation-packet/v1`, a matching accepted
  `upgrade-remediation-decision/v1`, its deterministic derived report, and a
  passing `incoming-candidate` validator execution receipt. Their digests,
  target root/HEAD/prestate, package, plan, selection, target validation
  profile, and prior provenance/customization identities must agree with the
  validated transaction. The decision's exact `policy_adoptions` value must
  equal the candidate provenance value, so cutover metadata cannot be invented
  during finalization. The decision also binds canonical digests of the full
  candidate provenance and customization ledger; any candidate authority drift
  requires a new decision. Rejected, stale, interrupted, or rolled-back records
  are retained but cannot update provenance or adoption metadata.
- Target validation is separate from incoming-package validation. After target
  writes, a separately routed canonical receipt must prove the exact target
  profile argv passed and bind its profile, output, timing, target, pending
  receipt, packet, decision, plan, and transaction identities before authority
  finalization.
- After successful authority publication, one immutable terminal receipt under
  the transaction binds the packet, decision, pending receipt, and resulting
  provenance/customization digests. The journal makes one terminal transition
  from `validated` to `finalized` while binding that receipt path/hash; it
  cannot change the sealed plan or earlier evidence.
- A finalized upgrade terminal receipt remains an active target invariant.
  Validation rejects missing, corrupt, unlinked, or authority-mismatched
  terminal evidence. An identical retry may complete only a missing exact
  terminal transition after interrupted authority publication.
- Do not treat an omitted rule record, a cached packet, or an action skill's
  memory as baseline acceptance. Missing, stale, ambiguous, unknown,
  unpacketized, or invariant-conflicting state fails closed until owner
  reconciliation regenerates the target-effective state and packets.
- The framework source repository stores the template only; it must not carry a self-referential target instance.

The governance-owned
`../../ai-context-governance/references/semantic-customization-lifecycle.md`
defines the ledger fields and four-skill lifecycle. The machine-readable schema
set is `../../ai-context-governance/templates/customizations.schema.yaml`,
`../../ai-context-governance/templates/effective-rule-state.schema.yaml`, and
`../../ai-context-governance/templates/effective-rule-packet.schema.yaml`.

Ordinary target-only requirements, ADRs, workflows, runbooks, maintenance
windows, test commands, enterprise network rules, and permission policies are
protected target truth. Record them in the ledger only when they change
framework-managed behavior. If an incoming release later introduces the same
path or contract, add unresolved reconciliation rather than inferring overwrite
authority.
